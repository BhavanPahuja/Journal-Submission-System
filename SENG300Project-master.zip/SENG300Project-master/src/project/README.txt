
The Main.java file is the file that starts the program