/*
Let's the author submit a journal and pick up to 3 preferential reviewers.
Also let's the author see the reviewer(s)' feedback and whether the journal was accepted, nedds minor revision, needs major revision or rejected.
After receiving feedback the author should be allowed to resubmit their journal for further review.
Authors cannot see who their reviewers are at anytime.
Authors need to submit their files in a .pdf format and download the reveiwer feedback as .pdf as well.
*/
