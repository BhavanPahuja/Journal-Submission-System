/*
Can download the journal and upload reviews and select accepted, rejected, major or minor revision.
The notifications class will send the reviewer a notification when an editor assigns a submission. 
The reviewer then downloads the submission, writes his review and uploads the file as pdf.
The reviewer then chooses if the author needs to make a major/minor revision.
The reviewer also gives his decision on if the submission is accepted/declined.
The reviewer's decision is then sent to the editor who then forwards the feedback to the author.
The reviewer also has their affiliations listed on the system so that teh author/editor can find them easily.
The reviewer is not able to see comments from other reviewers.

*/




//A function that opens a csv file, and gets all the file names 

//The filenames will populate a picking menu (the reviewer can pick from that menu, the applications 
//that they want to review)


