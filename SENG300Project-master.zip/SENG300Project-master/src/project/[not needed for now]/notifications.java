/*
Sends notifications to admin, authors, editors and reviewers.

As an Editor, I want to be notified when the reviewers are all done making decisions about the journal they are reviewing so that I can notify the author
As an Editor, I want to notify authors when and what the decision is about their journal submission 
As an Editor, I want to notify reviewers when they have been selected to review a journal

*/

