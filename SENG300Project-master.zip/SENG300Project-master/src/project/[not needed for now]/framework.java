package project;
/*
public class framework
{
	
	public adduser()
	{
		
	}
	
	public login()
	{
		
	}

	public notifications()
	{
		
	}
	
	public author()
	{
		
	}
	
	public editor()
	{
		
	}

	public reviewer()
	{
		
	}

	
	public static void main (String[] args)
	{
		//launch(args);
	}
}
*/