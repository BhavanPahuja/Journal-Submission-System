package project;

import javax.swing.JFrame;
import java.io.*;

public class verifyLoginGUI
{
	public static void main(String[] args) throws FileNotFoundException
	{
		JFrame frame = new verifyLogin();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
